# Security Policy

## Reporting Security Bugs

Please report security bugs found in the LiteSpeed Cache plugin's source code through the [Patchstack Vulnerability Disclosure Program](https://patchstack.com/database/vdp/litespeed-cache). The Patchstack team will assist you with verification, CVE assignment, and notify the developers of this plugin.
